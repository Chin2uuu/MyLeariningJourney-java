class First{
    /*
    public , static, void , class all are keywords. Reserve Words
    public - access outside the package (folder)
    static - load when class is loaded.
    void - no return 
    main - Entry point
    String args[]- Command Line Argument
    */
    static public  void main(String ...box) {
        // Logic   
       // System.out.print("Hello Java");
       System.out.println("*");
       System.out.println("*");
       System.out.println("*");
       System.out.println("*");
       System.out.println("*");
       System.out.print("*");
       System.out.print("*");
       System.out.print("*");
       System.out.print("*");
       System.out.print("*");
       System.out.println();

    }
}