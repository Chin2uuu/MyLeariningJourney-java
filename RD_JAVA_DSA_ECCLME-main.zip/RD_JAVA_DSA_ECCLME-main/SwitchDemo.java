public class SwitchDemo {
   public static void main(String[] args) {
       
   } 
}
